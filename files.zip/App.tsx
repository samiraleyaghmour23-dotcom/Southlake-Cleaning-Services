import { useState, useEffect, useRef } from 'react'
import './App.css'
import teamImg from './assets/team.png'
import kitchenImg from './assets/kitchen.png'
import officeImg from './assets/office.png'
import bedroomImg from './assets/bedroom.png'
import diningImg from './assets/dining.png'
import livingImg from './assets/living.png'

type Page = 'home' | 'about' | 'services' | 'work' | 'reviews' | 'contact'

export default function App() {
  const [page, setPage] = useState<Page>('home')
  const [menuOpen, setMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [formSent, setFormSent] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
    setMenuOpen(false)
  }, [page])

  const nav = (p: Page) => { setPage(p); setMenuOpen(false) }

  return (
    <div className="site-root">
      <header className={`site-nav ${scrolled ? 'scrolled' : ''}`}>
        <div className="nav-inner">
          <button className="logo-btn" onClick={() => nav('home')}>
            <PremiumLogo />
            <div className="logo-text-wrap">
              <span className="logo-name">SOUTHLAKE</span>
              <span className="logo-tagline">CLEANING SERVICES</span>
            </div>
          </button>
          <nav className="desktop-nav">
            {(['home','services','about','work','reviews','contact'] as Page[]).map(p => (
              <button key={p} onClick={() => nav(p)} className={`nav-link ${page === p ? 'active' : ''}`}>
                {p === 'home' ? 'Home' : p === 'work' ? 'Our Work' : p.charAt(0).toUpperCase() + p.slice(1)}
              </button>
            ))}
            <button className="nav-cta" onClick={() => nav('contact')}>Book Now</button>
          </nav>
          <button className="hamburger" onClick={() => setMenuOpen(!menuOpen)} aria-label="Menu">
            <span className={menuOpen ? 'open' : ''} /><span className={menuOpen ? 'open' : ''} /><span className={menuOpen ? 'open' : ''} />
          </button>
        </div>
        {menuOpen && (
          <div className="mobile-nav">
            {(['home','services','about','work','reviews','contact'] as Page[]).map(p => (
              <button key={p} onClick={() => nav(p)} className="mobile-link">
                {p === 'home' ? 'Home' : p === 'work' ? 'Our Work' : p.charAt(0).toUpperCase() + p.slice(1)}
              </button>
            ))}
            <a href="tel:4692033407" className="mobile-phone">&#9742; (469) 203-3407</a>
          </div>
        )}
      </header>

      <main>
        {page === 'home'     && <HomePage nav={nav} />}
        {page === 'about'    && <AboutPage nav={nav} />}
        {page === 'services' && <ServicesPage nav={nav} />}
        {page === 'work'     && <WorkPage nav={nav} />}
        {page === 'reviews'  && <ReviewsPage nav={nav} />}
        {page === 'contact'  && <ContactPage formSent={formSent} setFormSent={setFormSent} />}
      </main>

      <SiteFooter nav={nav} />
      <a href="tel:4692033407" className="sticky-call">&#9742; Call Now</a>
    </div>
  )
}

/* ─── PREMIUM LOGO ─── */
function PremiumLogo() {
  return (
    <svg width="52" height="52" viewBox="0 0 52 52" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect width="52" height="52" fill="#0a0a0a"/>
      <rect x="1" y="1" width="50" height="50" stroke="#C9A84C" strokeWidth="0.8" fill="none"/>
      {/* diamond top */}
      <polygon points="26,6 32,16 26,14 20,16" fill="#C9A84C"/>
      {/* stylized broom / sparkle */}
      <line x1="26" y1="14" x2="26" y2="34" stroke="#C9A84C" strokeWidth="1.5"/>
      <line x1="18" y1="34" x2="34" y2="34" stroke="#C9A84C" strokeWidth="1.5"/>
      <line x1="16" y1="37" x2="36" y2="37" stroke="#C9A84C" strokeWidth="1.2"/>
      <line x1="18" y1="40" x2="34" y2="40" stroke="#C9A84C" strokeWidth="0.9"/>
      {/* corner stars */}
      <circle cx="10" cy="10" r="1.2" fill="#C9A84C"/>
      <circle cx="42" cy="10" r="1.2" fill="#C9A84C"/>
      <circle cx="10" cy="42" r="1.2" fill="#C9A84C"/>
      <circle cx="42" cy="42" r="1.2" fill="#C9A84C"/>
      {/* small sparkles */}
      <circle cx="38" cy="20" r="1" fill="#C9A84C" opacity="0.7"/>
      <circle cx="14" cy="20" r="1" fill="#C9A84C" opacity="0.7"/>
    </svg>
  )
}

/* ─── HOME PAGE ─── */
function HomePage({ nav }: { nav: (p: Page) => void }) {
  const statsRef = useRef<HTMLDivElement>(null)
  const [visible, setVisible] = useState(false)
  const [counts, setCounts] = useState([0, 0, 0])

  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) setVisible(true) }, { threshold: 0.4 })
    if (statsRef.current) obs.observe(statsRef.current)
    return () => obs.disconnect()
  }, [])

  useEffect(() => {
    if (!visible) return
    const targets = [25, 5, 100]
    const timers = targets.map((t, i) => {
      let c = 0; const inc = t / 60
      const id = setInterval(() => {
        c = Math.min(c + inc, t)
        setCounts(prev => { const n = [...prev]; n[i] = Math.round(c); return n })
        if (Math.round(c) >= t) clearInterval(id)
      }, 1800 / 60)
      return id
    })
    return () => timers.forEach(clearInterval)
  }, [visible])

  return (
    <>
      {/* HERO */}
      <section className="hero">
        <div className="hero-overlay" />
        <img src={kitchenImg} alt="Pristine kitchen" className="hero-bg-img" />
        <div className="hero-content">
          <div className="hero-label-line"><span className="hero-line" /><span className="hero-eyebrow">DFW&apos;s Premier Cleaning Service</span><span className="hero-line" /></div>
          <h1 className="hero-title">Impeccable Cleanliness.<br /><em>Unmatched Excellence.</em></h1>
          <p className="hero-sub">25+ years of trusted, professional housecleaning across the Dallas–Fort Worth Metroplex. We don&apos;t just clean — we transform.</p>
          <div className="hero-btns">
            <button className="btn-gold" onClick={() => nav('contact')}>Request a Quote</button>
            <button className="btn-outline-white" onClick={() => nav('work')}>View Our Work</button>
          </div>
          <div className="hero-trust">
            <span className="hero-trust-item">&#9733; 5.0 Google Rating</span>
            <span className="hero-trust-sep">|</span>
            <span className="hero-trust-item">25+ Years Experience</span>
            <span className="hero-trust-sep">|</span>
            <span className="hero-trust-item">English Speaking</span>
          </div>
        </div>
        <div className="hero-scroll">&#8595;</div>
      </section>

      {/* GOLD DIVIDER BAR */}
      <div className="gold-bar">
        {['Licensed & Insured', 'Flexible Scheduling', 'Team of Professionals', 'Eco-Friendly Options', 'All DFW Metroplex', '5.0 &#9733; Rated'].map((t, i) => (
          <div key={i} className="gold-bar-item"><span className="gold-diamond">&#9670;</span> <span dangerouslySetInnerHTML={{__html: t}} /></div>
        ))}
      </div>

      {/* INTRO WITH FLOATING IMAGES */}
      <section className="intro-sec">
        <div className="intro-images">
          <div className="intro-img-main float-a"><img src={teamImg} alt="Professional cleaning team" /></div>
          <div className="intro-img-sm float-b"><img src={diningImg} alt="Clean dining room" /></div>
          <div className="intro-years-badge"><span className="years-num">25<sup>+</sup></span><span className="years-text">Years of<br/>Excellence</span></div>
        </div>
        <div className="intro-content">
          <div className="gold-label">Who We Are</div>
          <h2>A Legacy of Clean, Built on Trust</h2>
          <p>Our cleaning service was founded on one belief: your home deserves the highest standard of care. For over 25 years, we have served DFW families with honesty, precision, and genuine dedication to their comfort.</p>
          <p>We arrive as a trained team of 2–3 professionals — efficient, discreet, and held to our founder&apos;s exacting standards on every single visit.</p>
          <div className="intro-features">
            <div className="intro-feat"><span className="feat-check">&#10003;</span> Consistent quality — every visit, without exception</div>
            <div className="intro-feat"><span className="feat-check">&#10003;</span> Trustworthy, background-checked professionals</div>
            <div className="intro-feat"><span className="feat-check">&#10003;</span> Flexible scheduling around your lifestyle</div>
            <div className="intro-feat"><span className="feat-check">&#10003;</span> English-speaking — clear communication always</div>
          </div>
          <button className="btn-dark" onClick={() => nav('about')}>Our Story &rarr;</button>
        </div>
      </section>

      {/* SERVICES PREVIEW */}
      <section className="services-preview-sec">
        <div className="sec-head-centered">
          <div className="gold-label">What We Offer</div>
          <h2>Services Crafted for Excellence</h2>
          <p className="sec-sub">From routine care to deep transformation — every service delivered with the same unwavering standard.</p>
        </div>
        <div className="services-grid">
          {SERVICES.slice(0, 6).map(s => (
            <div key={s.title} className="svc-card">
              <div className="svc-icon-wrap"><span className="svc-icon">{s.icon}</span></div>
              <h3>{s.title}</h3>
              <p>{s.desc}</p>
              <span className="svc-tag">{s.tag}</span>
            </div>
          ))}
        </div>
        <div className="sec-cta"><button className="btn-gold" onClick={() => nav('services')}>All Services</button></div>
      </section>

      {/* STATS */}
      <section className="stats-sec" ref={statsRef}>
        <div className="stats-inner">
          <div className="stat-card"><span className="stat-num">{counts[0]}+</span><div className="stat-line" /><span className="stat-label">Years of Service</span></div>
          <div className="stat-card"><span className="stat-num">{counts[1]}.0</span><div className="stat-line" /><span className="stat-label">Google Rating</span></div>
          <div className="stat-card"><span className="stat-num">{counts[2]}%</span><div className="stat-line" /><span className="stat-label">Client Satisfaction</span></div>
        </div>
      </section>

      {/* GALLERY PREVIEW */}
      <section className="gallery-prev-sec">
        <div className="sec-head-centered">
          <div className="gold-label">Our Work</div>
          <h2>The Standard We Deliver</h2>
        </div>
        <div className="gallery-grid-home">
          <div className="gph-item gph-tall"><img src={kitchenImg} alt="Kitchen" /><div className="gph-label">Kitchen Deep Clean</div></div>
          <div className="gph-item"><img src={livingImg} alt="Living Room" /><div className="gph-label">Living Room</div></div>
          <div className="gph-item"><img src={bedroomImg} alt="Bedroom" /><div className="gph-label">Bedroom</div></div>
          <div className="gph-item"><img src={officeImg} alt="Office" /><div className="gph-label">Office / Upstairs</div></div>
          <div className="gph-item"><img src={diningImg} alt="Dining" /><div className="gph-label">Dining Area</div></div>
        </div>
        <div className="sec-cta"><button className="btn-dark" onClick={() => nav('work')}>Full Gallery &rarr;</button></div>
      </section>

      {/* REVIEWS STRIP */}
      <section className="reviews-strip-sec">
        <div className="reviews-strip-header">
          <div>
            <div className="gold-label">Client Reviews</div>
            <h2 style={{color:'#fff'}}>What Our Clients Say</h2>
          </div>
          <div className="reviews-rating-block">
            <span className="rr-score">5.0</span>
            <div><div className="rr-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div><div className="rr-count">10 verified Google reviews</div></div>
          </div>
        </div>
        <div className="reviews-strip-grid">
          {ALL_REVIEWS.slice(0, 3).map((r, i) => (
            <div key={i} className="rs-card">
              <div className="rs-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
              <p className="rs-text">&ldquo;{r.text}&rdquo;</p>
              <div className="rs-author"><div className="rs-avatar">{r.init}</div><div><div className="rs-name">{r.name}</div><div className="rs-date">{r.time}</div></div></div>
            </div>
          ))}
        </div>
        <div className="sec-cta"><button className="btn-gold" onClick={() => nav('reviews')}>All Reviews</button></div>
      </section>

      {/* CTA FINAL */}
      <section className="cta-final">
        <div className="cta-final-inner">
          <div className="gold-label" style={{textAlign:'center'}}>Ready to Begin?</div>
          <h2 style={{textAlign:'center',color:'#fff'}}>Experience the Difference</h2>
          <p style={{textAlign:'center',color:'rgba(255,255,255,0.75)',marginBottom:'2rem'}}>Call us today or request a free quote. Serving all of DFW.</p>
          <div className="cta-final-btns">
            <a href="tel:4692033407" className="btn-gold">&#9742; (469) 203-3407</a>
            <button className="btn-outline-white" onClick={() => nav('contact')}>Request a Quote</button>
          </div>
        </div>
      </section>
    </>
  )
}

/* ─── ABOUT PAGE ─── */
function AboutPage({ nav }: { nav: (p: Page) => void }) {
  return (
    <>
      <section className="page-hero">
        <div className="ph-overlay" />
        <img src={teamImg} alt="Our team" className="ph-bg" />
        <div className="ph-content">
          <div className="gold-label">Our Story</div>
          <h1>Built on Trust.<br/>Sustained by Excellence.</h1>
          <p>Over 25 years of professional housecleaning across the Dallas–Fort Worth Metroplex.</p>
        </div>
      </section>

      <section className="about-story-sec">
        <div className="about-story-grid">
          <div className="about-story-imgs">
            <img src={teamImg} alt="Our team at work" className="as-img-main float-a" />
            <img src={kitchenImg} alt="Clean kitchen" className="as-img-overlay float-b" />
          </div>
          <div className="about-story-text">
            <div className="gold-label">About Us</div>
            <h2>A Business Born from Genuine Care</h2>
            <p>More than two decades ago, our cleaning service was founded with a simple but powerful mission: to treat every client&apos;s home with the same care and respect that we would give our own.</p>
            <p>Over the years, that mission has never wavered. We have built lasting relationships with hundreds of DFW families — many of whom have trusted us for 6, 8, even 10+ years. That loyalty is our greatest achievement.</p>
            <p>We are English-speaking, fully insured, and deeply committed to the trust you place in us every time we enter your home.</p>
            <button className="btn-dark" onClick={() => nav('contact')}>Get in Touch &rarr;</button>
          </div>
        </div>
      </section>

      <section className="values-sec">
        <div className="sec-head-centered">
          <div className="gold-label">What We Stand For</div>
          <h2>Our Core Values</h2>
        </div>
        <div className="values-grid">
          {[
            {icon:'&#9670;', title:'Integrity', desc:'Honest, transparent, and always respectful of your home and your trust.'},
            {icon:'&#9670;', title:'Precision', desc:'From baseboards to ceilings — every detail matters. Nothing is overlooked.'},
            {icon:'&#9670;', title:'Reliability', desc:'We show up on time, every time. You can schedule your day around us.'},
            {icon:'&#9670;', title:'Excellence', desc:'We hold ourselves to the highest standard, on every visit, without exception.'},
          ].map(v => (
            <div key={v.title} className="value-card">
              <div className="value-icon" dangerouslySetInnerHTML={{__html: v.icon}} />
              <h3>{v.title}</h3>
              <p>{v.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="diff-sec">
        <div className="diff-inner">
          <div className="gold-label">The Difference</div>
          <h2>Why DFW Families Choose Us</h2>
          <div className="diff-grid">
            {[
              ['Team-based cleaning','2–3 professionals ensure efficiency without overstaying'],
              ['Consistent standards','Every team member trained to the same exacting level'],
              ['No shortcuts taken','We clean what others skip — walls, fans, baseboards, hidden corners'],
              ['Flexible scheduling','We work around your life, not the other way around'],
              ['Proven track record','25+ years, hundreds of happy clients, perfect 5.0 rating'],
              ['English speaking','Clear, direct communication — your needs are always understood'],
            ].map(([t, d]) => (
              <div key={t} className="diff-item">
                <div className="diff-diamond">&#9670;</div>
                <div><strong>{t}</strong><br /><span style={{color:'rgba(255,255,255,0.65)',fontSize:'0.88rem'}}>{d}</span></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="cta-final">
        <div className="cta-final-inner">
          <h2 style={{textAlign:'center',color:'#fff'}}>Ready to Work With Us?</h2>
          <p style={{textAlign:'center',color:'rgba(255,255,255,0.75)',marginBottom:'2rem'}}>Join hundreds of DFW families who trust us with their most important space.</p>
          <div className="cta-final-btns"><button className="btn-gold" onClick={() => nav('contact')}>Request a Free Quote</button></div>
        </div>
      </section>
    </>
  )
}

/* ─── SERVICES ─── */
const SERVICES = [
  {icon:'◈', title:'Regular House Cleaning', desc:'Scheduled visits to keep your home consistently pristine. Dusting, vacuuming, mopping, sanitizing — every room, every time.', tag:'Weekly · Bi-weekly · Monthly'},
  {icon:'✦', title:'Deep Cleaning', desc:'A thorough, top-to-bottom clean. Walls, baseboards, inside appliances, ceiling fans, and every hidden surface.', tag:'One-time · Seasonal'},
  {icon:'⬜', title:'Move-In / Move-Out', desc:'Start fresh or leave spotless. We ensure the property meets the highest standard for the next chapter.', tag:'Before or After Moving'},
  {icon:'◻', title:'Commercial Cleaning', desc:'Professional cleaning for offices and retail spaces. Scheduled around your operations for zero disruption.', tag:'Offices · Retail · Facilities'},
  {icon:'◈', title:'Airbnb & Rental Cleaning', desc:'Hotel-level turnovers that impress every guest. Reliable, fast, and immaculate — every single time.', tag:'Short-term Rentals'},
  {icon:'✦', title:'Post-Event Cleaning', desc:'After gatherings and special occasions, we restore your home swiftly and completely.', tag:'Same-day Available'},
  {icon:'◈', title:'Eco-Friendly Cleaning', desc:'Effective green solutions using environmentally responsible products. Clean without compromise.', tag:'On Request'},
  {icon:'◻', title:'Post-Construction Clean', desc:'Remove dust, debris, and construction residue. Your new space, truly ready to live in.', tag:'New Builds & Remodels'},
]

function ServicesPage({ nav }: { nav: (p: Page) => void }) {
  return (
    <>
      <section className="page-hero">
        <div className="ph-overlay" />
        <img src={kitchenImg} alt="Clean kitchen" className="ph-bg" />
        <div className="ph-content">
          <div className="gold-label">Services</div>
          <h1>Excellence in Every Detail</h1>
          <p>A complete range of professional cleaning services, tailored to your home and your life.</p>
        </div>
      </section>

      <section className="services-full-sec">
        <div className="sec-head-centered">
          <div className="gold-label">What We Offer</div>
          <h2>Our Complete Service Menu</h2>
          <p className="sec-sub">Each service is executed with the same precision and care that has defined us for over 25 years.</p>
        </div>
        <div className="services-grid full">
          {SERVICES.map(s => (
            <div key={s.title} className="svc-card">
              <div className="svc-icon-wrap"><span className="svc-icon-text">{s.icon}</span></div>
              <h3>{s.title}</h3>
              <p>{s.desc}</p>
              <span className="svc-tag">{s.tag}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="how-sec">
        <div className="sec-head-centered">
          <div className="gold-label">The Process</div>
          <h2>How It Works</h2>
        </div>
        <div className="steps-row">
          {[
            {n:'01', t:'Contact Us', d:"Call, text, or fill out our form. We'll discuss your needs and preferences."},
            {n:'02', t:'Receive Your Quote', d:'Transparent, fair pricing based on your space and selected services. No surprises.'},
            {n:'03', t:'We Clean', d:'Our professional team arrives on schedule and works with care and efficiency.'},
            {n:'04', t:'You Enjoy', d:"Come home to a flawlessly clean space. Love it — or we'll make it right."},
          ].map(s => (
            <div key={s.n} className="step-card">
              <div className="step-num">{s.n}</div>
              <h3>{s.t}</h3>
              <p>{s.d}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="cta-final">
        <div className="cta-final-inner">
          <h2 style={{textAlign:'center',color:'#fff'}}>Not Sure Which Service You Need?</h2>
          <p style={{textAlign:'center',color:'rgba(255,255,255,0.75)',marginBottom:'2rem'}}>Call us — we&apos;ll help you find the perfect fit for your home.</p>
          <div className="cta-final-btns">
            <a href="tel:4692033407" className="btn-gold">&#9742; (469) 203-3407</a>
            <button className="btn-outline-white" onClick={() => nav('contact')}>Request a Quote</button>
          </div>
        </div>
      </section>
    </>
  )
}

/* ─── WORK / GALLERY ─── */
const GALLERY = [
  {img: kitchenImg, title:'Kitchen Deep Clean', sub:'Granite countertops, appliances & cabinetry', wide: true},
  {img: livingImg,  title:'Living Room',        sub:'Full dusting, vacuuming & surface care',       wide: false},
  {img: bedroomImg, title:'Guest Bedroom',       sub:'Rental-ready presentation',                   wide: false},
  {img: diningImg,  title:'Dining & Kitchen',    sub:'Open-plan full clean',                        wide: true},
  {img: officeImg,  title:'Upper Floor / Office',sub:'Floors, walls & workspace',                   wide: false},
  {img: teamImg,    title:'Team at Work',        sub:'Our professionals in action',                 wide: false},
]

function WorkPage({ nav }: { nav: (p: Page) => void }) {
  const [active, setActive] = useState<number | null>(null)
  return (
    <>
      <section className="page-hero">
        <div className="ph-overlay" />
        <img src={livingImg} alt="Living room" className="ph-bg" />
        <div className="ph-content">
          <div className="gold-label">Our Work</div>
          <h1>The Results Speak<br/>for Themselves</h1>
          <p>Real homes. Real cleans. Real results — delivered consistently for over 25 years.</p>
        </div>
      </section>

      <section className="work-gallery-sec">
        <div className="sec-head-centered">
          <div className="gold-label">Gallery</div>
          <h2>Every Home We Touch</h2>
          <p className="sec-sub">Click any photo to view full size.</p>
        </div>
        <div className="work-grid">
          {GALLERY.map((g, i) => (
            <div key={i} className={`work-item ${g.wide ? 'wide' : ''}`} onClick={() => setActive(i)}>
              <img src={g.img} alt={g.title} />
              <div className="work-overlay">
                <span className="work-title">{g.title}</span>
                <span className="work-sub-label">{g.sub}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {active !== null && (
        <div className="lightbox" onClick={() => setActive(null)}>
          <button className="lb-close" onClick={() => setActive(null)}>&#10005;</button>
          <div className="lb-card" onClick={e => e.stopPropagation()}>
            <img src={GALLERY[active].img} alt={GALLERY[active].title} />
            <div className="lb-info">
              <strong>{GALLERY[active].title}</strong>
              <span>{GALLERY[active].sub}</span>
            </div>
            <div className="lb-nav">
              <button onClick={() => setActive((active - 1 + GALLERY.length) % GALLERY.length)}>&#8592; Prev</button>
              <button onClick={() => setActive((active + 1) % GALLERY.length)}>Next &#8594;</button>
            </div>
          </div>
        </div>
      )}

      <section className="cta-final">
        <div className="cta-final-inner">
          <h2 style={{textAlign:'center',color:'#fff'}}>Want Results Like These?</h2>
          <p style={{textAlign:'center',color:'rgba(255,255,255,0.75)',marginBottom:'2rem'}}>Book a cleaning and experience the standard we&apos;ve upheld for 25+ years.</p>
          <div className="cta-final-btns"><button className="btn-gold" onClick={() => nav('contact')}>Book Now</button></div>
        </div>
      </section>
    </>
  )
}

/* ─── REVIEWS ─── */
const ALL_REVIEWS = [
  {name:'Juan Montoya',   init:'JM', time:'1 year ago',   text:"Their attention to detail is impeccable! Every cleaning, they leave the house looking so presentable and smelling great. Her personality is another big plus — always willing to work on my schedule. I highly recommend and will continue to do business with her!"},
  {name:'Joan Wellborn',  init:'JW', time:'5 years ago',  text:"She has been working for me for many years. A self starter with wonderful attention to detail. She thoroughly trains her assistants so the house is cleaned to her standard even when she isn't there. Honest and hardworking. I recommend without reservation."},
  {name:'Bra Ben',        init:'BB', time:'5 years ago',  text:"They do a wonderful job on my home every time. They dust everything — including the walls! They clean items I don't even expect them to clean. She has a great heart and treats us like family. 💖"},
  {name:'Katherine Taylor',init:'KT',time:'5 years ago',  text:"Has been cleaning our house for 8 years and is wonderful! Reliable and does an excellent job. I highly recommend her!"},
  {name:'Janet McKinney', init:'JM', time:'5 years ago',  text:"I have used this company for many years — she and her team are trustworthy and hardworking. Very thorough; they clean things I wouldn't have thought of. Prices are great, you will love her and her team!"},
  {name:'Alexa Santamaria',init:'AS',time:'5 years ago',  text:"The work is SPECTACULAR! She treats my home as if it were her own! I highly recommend her to anyone. Please give her a try — I promise you won't be disappointed!"},
  {name:'D H',            init:'DH', time:'5 years ago',  text:"Leaves my home spotless. Reliable, trustworthy, honest, and kind. I have been a client for 8 years and highly recommend her services."},
  {name:'Susan Fiorelli', init:'SF', time:'5 years ago',  text:"For 6 years and counting, the team has come into our home to make it sparkle. And more importantly, she is responsible and trustworthy."},
  {name:'Ann Dachniwsky', init:'AD', time:'5 years ago',  text:"We loved having the crew clean for us. They are very good at what they do."},
  {name:'Abidur Serniabat',init:'AB',time:'7 months ago', text:"Amazing service! Thank you so much!"},
]

function ReviewsPage({ nav }: { nav: (p: Page) => void }) {
  return (
    <>
      <section className="page-hero">
        <div className="ph-overlay" />
        <img src={bedroomImg} alt="Clean bedroom" className="ph-bg" />
        <div className="ph-content">
          <div className="gold-label">Client Reviews</div>
          <h1>Trusted by Hundreds<br/>of DFW Families</h1>
          <div className="ph-rating"><span className="ph-score">5.0</span><div><div className="ph-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div><div className="ph-rc">10 verified Google reviews</div></div></div>
        </div>
      </section>

      <section className="reviews-full-sec">
        <div className="reviews-all-grid">
          {ALL_REVIEWS.map((r, i) => (
            <div key={i} className="review-card-premium">
              <div className="rcp-top">
                <div className="rcp-avatar">{r.init}</div>
                <div><div className="rcp-name">{r.name}</div><div className="rcp-date">{r.time}</div></div>
              </div>
              <div className="rcp-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
              <p className="rcp-text">&ldquo;{r.text}&rdquo;</p>
            </div>
          ))}
        </div>
        <div className="reviews-google-box">
          <div className="rgb-inner">
            <div className="rgb-score">5.0</div>
            <div className="rgb-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
            <p className="rgb-label">on Google Maps</p>
            <a href="https://www.google.com/maps" target="_blank" rel="noopener noreferrer" className="btn-gold">View on Google</a>
          </div>
        </div>
      </section>

      <section className="cta-final">
        <div className="cta-final-inner">
          <h2 style={{textAlign:'center',color:'#fff'}}>Ready to Become Our Next 5-Star Review?</h2>
          <p style={{textAlign:'center',color:'rgba(255,255,255,0.75)',marginBottom:'2rem'}}>Experience the cleaning service DFW families have trusted for over 25 years.</p>
          <div className="cta-final-btns"><button className="btn-gold" onClick={() => nav('contact')}>Book a Cleaning</button></div>
        </div>
      </section>
    </>
  )
}

/* ─── CONTACT ─── */
function ContactPage({ formSent, setFormSent }: { formSent: boolean; setFormSent: (v: boolean) => void }) {
  const [form, setForm] = useState({name:'',phone:'',email:'',service:'',message:''})
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement|HTMLSelectElement|HTMLTextAreaElement>) =>
    setForm(f => ({...f, [k]: e.target.value}))
  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.name || !form.email) { alert('Please enter your name and email.'); return }
    setFormSent(true)
  }
  const areas = ['Grand Prairie','Southlake','Arlington','Irving','Fort Worth','Dallas','Grapevine','Colleyville','Keller','Hurst','Euless','Bedford','Frisco','Plano','McKinney','Carrollton','Flower Mound','Lewisville']
  return (
    <>
      <section className="page-hero">
        <div className="ph-overlay" />
        <img src={diningImg} alt="Clean space" className="ph-bg" />
        <div className="ph-content">
          <div className="gold-label">Contact</div>
          <h1>Let&apos;s Begin.</h1>
          <p>Request a free quote or call us directly. We respond within 24 hours.</p>
        </div>
      </section>

      <section className="contact-sec">
        <div className="contact-layout">
          <div className="contact-info-col">
            <div className="gold-label">Get in Touch</div>
            <h2>We&apos;d Love to Hear From You</h2>
            <div className="contact-items-list">
              <div className="ci"><div className="ci-icon-box">&#9742;</div><div><div className="ci-lbl">Phone / Text</div><a href="tel:4692033407" className="ci-val">(469) 203-3407</a></div></div>
              <div className="ci"><div className="ci-icon-box">&#9679;</div><div><div className="ci-lbl">Address</div><span className="ci-val">1196 Meadows Dr, Grand Prairie, TX 75052</span></div></div>
              <div className="ci"><div className="ci-icon-box">&#9711;</div><div><div className="ci-lbl">Hours</div><span className="ci-val">Monday – Saturday: 8:00 AM – 7:00 PM</span></div></div>
              <div className="ci"><div className="ci-icon-box">&#9670;</div><div><div className="ci-lbl">Service Area</div><span className="ci-val">All DFW Metroplex</span></div></div>
            </div>
            <div className="areas-block">
              <p className="areas-title">Cities We Serve</p>
              <div className="areas-wrap">{areas.map(a => <span key={a} className="area-chip">{a}</span>)}</div>
            </div>
            <img src={officeImg} alt="Clean office area" className="contact-side-img float-a" />
          </div>

          <div className="contact-form-col">
            <div className="form-card">
              <h3>Request a Free Quote</h3>
              {formSent ? (
                <div className="form-success">
                  <div className="fs-icon">&#10003;</div>
                  <h3>Message Received</h3>
                  <p>Thank you for reaching out. We&apos;ll contact you within 24 hours.<br/>Or call us directly: <a href="tel:4692033407">(469) 203-3407</a></p>
                </div>
              ) : (
                <form onSubmit={submit}>
                  <div className="form-row">
                    <div className="fg"><label>Full Name *</label><input value={form.name} onChange={set('name')} placeholder="Jane Doe" /></div>
                    <div className="fg"><label>Phone</label><input value={form.phone} onChange={set('phone')} placeholder="(xxx) xxx-xxxx" /></div>
                  </div>
                  <div className="fg"><label>Email *</label><input type="email" value={form.email} onChange={set('email')} placeholder="jane@example.com" /></div>
                  <div className="fg">
                    <label>Service Needed</label>
                    <select value={form.service} onChange={set('service')}>
                      <option value="">Select a service…</option>
                      {SERVICES.map(s => <option key={s.title}>{s.title}</option>)}
                      <option>Other / Not Sure</option>
                    </select>
                  </div>
                  <div className="fg">
                    <label>About Your Home</label>
                    <textarea value={form.message} onChange={set('message')} rows={4} placeholder="Bedrooms, bathrooms, square footage, special requests…" />
                  </div>
                  <button type="submit" className="btn-submit-form">Send Request &rarr;</button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

/* ─── FOOTER ─── */
function SiteFooter({ nav }: { nav: (p: Page) => void }) {
  return (
    <footer className="site-footer">
      <div className="footer-top">
        <div className="footer-brand">
          <button className="logo-btn" onClick={() => nav('home')}>
            <PremiumLogo />
            <div className="logo-text-wrap">
              <span className="logo-name" style={{color:'#fff'}}>SOUTHLAKE</span>
              <span className="logo-tagline">CLEANING SERVICES</span>
            </div>
          </button>
          <p className="footer-desc">Professional housecleaning across the DFW Metroplex. Trusted by families for over 25 years of impeccable service.</p>
          <a href="tel:4692033407" className="footer-phone">&#9742; (469) 203-3407</a>
        </div>
        <div className="footer-col">
          <h4>Services</h4>
          <ul>{SERVICES.slice(0,5).map(s => <li key={s.title}><button onClick={() => nav('services')}>{s.title}</button></li>)}</ul>
        </div>
        <div className="footer-col">
          <h4>Company</h4>
          <ul>
            {([['About Us','about'],['Our Work','work'],['Reviews','reviews'],['Contact','contact'],['Services','services']] as [string,Page][]).map(([l,p]) => (
              <li key={l}><button onClick={() => nav(p)}>{l}</button></li>
            ))}
          </ul>
        </div>
        <div className="footer-col">
          <h4>Service Areas</h4>
          <ul>{['Grand Prairie','Southlake','Arlington','Fort Worth','Dallas','Frisco','McKinney','All DFW'].map(a => <li key={a}><button onClick={() => nav('contact')}>{a}</button></li>)}</ul>
        </div>
      </div>
      <div className="footer-bottom">
        <p>&#169; 2026 Southlake Cleaning Services &middot; Grand Prairie, TX &middot; All rights reserved</p>
        <p>&#9733; 5.0 on Google &middot; Serving All DFW</p>
      </div>
    </footer>
  )
}
